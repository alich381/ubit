import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "20"))

DEVS = list(map(int, os.getenv("DEVS", "7300602830").split()))

API_ID = int(os.getenv("API_ID", "35822234"))

API_HASH = os.getenv("API_HASH", "cdec210eb9f17b0d2ea3d75d77436dee")

BOT_TOKEN = os.getenv("BOT_TOKEN", "8745574048:AAGcR3F91DGCPCc2LoP-l-mNOmfTqDKJmc4")

OWNER_ID = int(os.getenv("OWNER_ID", "7300602830"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1003192483568").split()))

RMBG_API = os.getenv("RMBG_API", "a6qxsmMJ3CsNo7HyxuKGsP1o")

MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://ekikpuka_db_user:VY5moQUFZ3OyMCSp@cluster0.isezhre.mongodb.net/?appName=Cluster0")

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", "-1002739847341"))
